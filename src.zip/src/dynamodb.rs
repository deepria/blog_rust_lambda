use aws_config::BehaviorVersion;
use aws_sdk_dynamodb::{types::AttributeValue, Client};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestEntity {
    pub id: String,
    pub value: Option<String>,
}

pub async fn dynamodb_client() -> Client {
    let config = aws_config::load_defaults(BehaviorVersion::latest()).await;
    Client::new(&config)
}

pub async fn get_item_value(
    table_name: &str,
    part: String,
    index: String,
) -> Result<Option<String>, Box<dyn std::error::Error + Send + Sync>> {
    let client = dynamodb_client().await;

    if table_name == "deepria" {
        // Use Query instead of GetItem for "deepria"
        let output = client
            .query()
            .table_name(table_name)
            .key_condition_expression("PrimaryKey = :pk")
            .filter_expression("part_001 = :part")
            .expression_attribute_values(":pk", AttributeValue::S(index.clone()))
            .expression_attribute_values(":part", AttributeValue::S(part.clone()))
            .send()
            .await?;

        let items_opt = output.items;
        let first_item = match items_opt.and_then(|mut items| items.pop()) {
            Some(item) => item,
            None => return Ok(None),
        };
        let value = match first_item.get("value") {
            Some(AttributeValue::S(s)) => Some(s.clone()),
            _ => None,
        };
        Ok(value)
    } else {
        let mut key = HashMap::new();
        key.insert("part".to_string(), AttributeValue::S(part));
        let output = client
            .get_item()
            .table_name(table_name)
            .set_key(Some(key))
            .send()
            .await?;
        let item = match output.item {
            Some(item) => item,
            None => return Ok(None),
        };
        let value = match item.get("value") {
            Some(AttributeValue::S(s)) => Some(s.clone()),
            _ => None,
        };
        Ok(value)
    }
}
pub async fn put_item(
    table_name: &str,
    part: String,
    index: String,
    value: String,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let client = dynamodb_client().await;

    let mut item = HashMap::new();
    if table_name == "deepria" {
        item.insert("PrimaryKey".to_string(), AttributeValue::S(index.clone()));
        item.insert("part_001".to_string(), AttributeValue::S(part));
        item.insert("index_001".to_string(), AttributeValue::S(index));
    } else {
        item.insert("part".to_string(), AttributeValue::S(part));
    }
    item.insert("value".to_string(), AttributeValue::S(value));

    client
        .put_item()
        .table_name(table_name)
        .set_item(Some(item))
        .send()
        .await?;

    Ok(())
}

pub async fn delete_item(
    table_name: &str,
    part: String,
    index: String,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let client = dynamodb_client().await;

    let mut key = HashMap::new();
    if table_name == "deepria" {
        key.insert("PrimaryKey".to_string(), AttributeValue::S(index));
    } else {
        key.insert("part".to_string(), AttributeValue::S(part));
    }

    client
        .delete_item()
        .table_name(table_name)
        .set_key(Some(key))
        .send()
        .await?;

    Ok(())
}

pub async fn scan_test_entities(
    table_name: &str,
) -> Result<Vec<TestEntity>, Box<dyn std::error::Error + Send + Sync>> {
    let client = dynamodb_client().await;

    let output = client.scan().table_name(table_name).send().await?;

    let mut results = Vec::new();

    if let Some(items) = output.items {
        for item in items {
            let id = match item.get("id") {
                Some(AttributeValue::S(s)) => s.clone(),
                _ => continue,
            };

            let value = match item.get("value") {
                Some(AttributeValue::S(s)) => Some(s.clone()),
                _ => None,
            };

            results.push(TestEntity { id, value });
        }
    }

    Ok(results)
}

pub async fn query_test_entities_by_id(
    table_name: &str,
    id: String,
) -> Result<Vec<TestEntity>, Box<dyn std::error::Error + Send + Sync>> {
    let client = dynamodb_client().await;

    let output = client
        .query()
        .table_name(table_name)
        .key_condition_expression("id = :id")
        .expression_attribute_values(":id", AttributeValue::S(id))
        .send()
        .await?;

    let mut results = Vec::new();

    if let Some(items) = output.items {
        for item in items {
            let id = match item.get("id") {
                Some(AttributeValue::S(s)) => s.clone(),
                _ => continue,
            };

            let value = match item.get("value") {
                Some(AttributeValue::S(s)) => Some(s.clone()),
                _ => None,
            };

            results.push(TestEntity { id, value });
        }
    }

    Ok(results)
}

pub async fn upsert_test_entity(
    table_name: &str,
    id: String,
    value: Option<String>,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let client = dynamodb_client().await;

    let mut item = HashMap::new();
    item.insert("id".to_string(), AttributeValue::S(id));

    if let Some(v) = value {
        item.insert("value".to_string(), AttributeValue::S(v));
    }

    client
        .put_item()
        .table_name(table_name)
        .set_item(Some(item))
        .send()
        .await?;

    Ok(())
}

pub async fn delete_test_entity_by_id(
    table_name: &str,
    id: String,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let client = dynamodb_client().await;

    let mut key = HashMap::new();
    key.insert("id".to_string(), AttributeValue::S(id));

    client
        .delete_item()
        .table_name(table_name)
        .set_key(Some(key))
        .send()
        .await?;

    Ok(())
}
